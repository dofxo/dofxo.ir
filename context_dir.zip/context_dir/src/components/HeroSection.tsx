import { useContext, useEffect, useState } from "react";
import { Button } from "./ui/button";
import { Slide } from "react-awesome-reveal";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { MainContext } from "@/context";

const token = import.meta.env.VITE_GITHUB_TOKEN;

const HeroSection = () => {
  const [avatarUrl, setAvatarUrl] = useState();
  const [isLoading, setIsLoading] = useState(false);

  const noGithub = true

  const { translations } = useContext(MainContext);

  useEffect(() => {
    (async () => {
      setIsLoading(true);
      const response = await fetch("https://api.github.com/users/dofxo", {
        headers: {
          Authorization: token,
        },
      });
      const { avatar_url } = await response.json();
      setIsLoading(false);
      setAvatarUrl(avatar_url);
    })();
  }, []);
  return (
    <section className="mt-[50px]">
      <div className="container flex flex-col-reverse gap-10 items-center md:flex-row justify-between">
        <div className="about-me text-center md:text-start">
          <Slide duration={500} triggerOnce>
            <h1 className="text-[var(--text-color)] font-bold text-[30px] md:text-[45px]">
              {translations.name}
            </h1>
          </Slide>
          <Slide duration={500} delay={50} triggerOnce>
            <h1 className="text-[var(--text-color)]  text-[18px] font-[500]">
              {translations.jobTitle}
            </h1>
          </Slide>
          <Slide duration={500} delay={100} triggerOnce>
            <p className="text-[var(--text-secondary-color)]  text-[12px] md:text-[14px] leading-[30px] max-w-[500px] mt-5">
              {translations.jobDescription}
            </p>
          </Slide>
          <Slide duration={500} delay={150} triggerOnce>
            <Button
              asChild
              className="text-[var(--button-text-color)]  bg-[var(--primary)] mt-[15px] rounded-[20px]"
            >
              <a
                href="https://cvresume.ir/r/Aqul4IS93UaK73uEh0AusQ"
                target="_blank"
              >
                {translations.resumeLink}
              </a>
            </Button>
          </Slide>
        </div>
        <div className="w-[200px] flex justify-center md:w-[300px]">
          {!isLoading ? (
            <LazyLoadImage
              src={avatarUrl ?? ""}
              alt="dofxoImage"
              className="rounded-full"
            />
          ) : (
            !noGithub && <div className="loader"></div>
          )}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
